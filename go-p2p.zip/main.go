package main

import (
	"./config"
	"./logger"
	"fmt"
	"net"
	"log"
	"os"
	"io"
	"encoding/binary"
	"io/ioutil"
	"path"
	"time"
)

func main(){
	defer func() {
		fmt.Println("log file closed")
		logger.Close()
	}()

	fmt.Println(config.Config)
	logger.Log("==========[go-server launching]==========")

	if len(os.Args) < 2{
		fmt.Println("too few arguments")
		os.Exit(1)
	}

	if os.Args[1] == "-c" {
		if len(os.Args) < 4{
			fmt.Println("too few arguments for client to send a file")
			os.Exit(1)
		}

		clientExec(os.Args[2], os.Args[3])
	}else if os.Args[1] == "-s" {
		serverExec()
	}else {
		fmt.Println("bad arguments")
		os.Exit(1)
	}
}

func checkError(err error)  {
	if err != nil {
		log.Fatal(err)
	}
}

func clientExec(server, file string)  {
	timeBegin := time.Now()
	fmt.Println("begin time: ", timeBegin)
	tcpAddr, err := net.ResolveTCPAddr("tcp", server)
	checkError(err)

	conn, err := net.DialTCP("tcp", nil, tcpAddr)
	checkError(err)

	buf, err := ioutil.ReadFile(file)
	checkError(err)

	fileNameSize := len(file)
	fileDataSize := len(buf)
	msgSize := uint32(4 + 2 + fileNameSize + fileDataSize)
	fmt.Println("msg size: ", msgSize, 4, 2, fileNameSize, fileDataSize)

	sendBuf := make([]byte, msgSize)

	msgSizeBuf := make([]byte, 4)
	binary.LittleEndian.PutUint32(msgSizeBuf, msgSize)

	fmt.Println("parsed msg size: ", binary.LittleEndian.Uint32(msgSizeBuf))

	fileNameSizeBuf := make([]byte, 2)
	binary.LittleEndian.PutUint16(fileNameSizeBuf, uint16(len(file)))

	copy(sendBuf[0: 4], msgSizeBuf)
	copy(sendBuf[4: 6], fileNameSizeBuf)
	copy(sendBuf[4 + 2: 4 + 2 + fileNameSize], []byte(file))
	copy(sendBuf[4 + 2 + fileNameSize :  ], buf)

	conn.Write(sendBuf)

	defer func() {
		fmt.Println("connection closed.")
		conn.Close()
	}()

	timeEnd := time.Now()
	fmt.Println("end time: ", timeEnd, "\nsend file finished.")
	usedTimeSeconds := (uint64(timeEnd.Sub(timeBegin)) / uint64(time.Second))
	totalMegaSize := uint64(msgSize / uint32(1024) / uint32(1024))
	if usedTimeSeconds == 0 {
		fmt.Println("used time: ", usedTimeSeconds,
			"speed: ", "within 1 second")
	}else {
		fmt.Println("used time: ", usedTimeSeconds,
			"speed: ", totalMegaSize / usedTimeSeconds, "M/s")
	}

	time.Sleep(time.Second * 1)
}

func serverExec()  {
	tcpAddr, err := net.ResolveTCPAddr("tcp", ":12345")
	checkError(err)

	server, err := net.ListenTCP("tcp", tcpAddr)
	checkError(err)

	defer server.Close()

	for {
		conn, err  := server.AcceptTCP()
		if err != nil {
			continue
		}

		go func() {
			for  {
				var (
					msgSizeBuf []byte = make([]byte, 4)
					msgSize uint32
					fileNameSizeBuf []byte = make([]byte, 2)
				)

				if _, err := io.ReadFull(conn, msgSizeBuf); err != nil {
					fmt.Println("recv failed, ", err)
					break
				}

				msgSize = binary.LittleEndian.Uint32(msgSizeBuf)
				fmt.Println("will recv size: ", msgSize)

				buf := make([]byte, msgSize - 4)
				if n, err := io.ReadFull(conn, buf); err != nil {
					fmt.Println("recv data into buf failed, total: , ", n, err)
					break
				}

				copy(fileNameSizeBuf, buf[0:2])
				fileNameSize := binary.LittleEndian.Uint16(fileNameSizeBuf)
				fileNameBuf := make([]byte, fileNameSize)
				copy(fileNameBuf, buf[2 : 2 + fileNameSize])
				fmt.Println("recv file name: ", string(fileNameBuf))
				outputFile, err := os.OpenFile(path.Base(string(fileNameBuf)), os.O_CREATE | os.O_WRONLY, 0644)
				if err != nil {
					fmt.Println("create file failed: ", string(fileNameBuf))
					break
				}

				defer outputFile.Close()

				if _, err := outputFile.Write(buf[2 + fileNameSize : ]); err != nil {
					fmt.Println("write file failed, ", err)
					break
				}

				fmt.Println("recv file finished.")

				defer conn.Close()

				break
			}
		}()
	}
}
