package signal

import (
	"../config"
	"../logger"
)

func init()  {
	logger.Log("signal package init")
	config.Config
}