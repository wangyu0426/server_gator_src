package config

import "fmt"

type ServerConfig struct {
	LogDir string
	BindAddr string
	Port uint16
}

var Config ServerConfig

func init()  {
	fmt.Println("config init...")
	Config.LogDir = "/home/work/logs"
	Config.BindAddr = "0.0.0.0"
	Config.Port = 7015
}
